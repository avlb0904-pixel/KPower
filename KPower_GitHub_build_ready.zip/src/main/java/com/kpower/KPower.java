package com.kpower;

public class KPower {
    public static final String MODID = "kpower";
    public static final String NAME = "KPower";
    public static final String VERSION = "1.0.0";

    public KPower() {
        // Initialization hooks (requires NeoForge/Forge APIs)
    }
}
